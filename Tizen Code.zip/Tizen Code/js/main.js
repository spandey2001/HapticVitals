( function () {
    window.addEventListener( 'tizenhwkey', function( ev ) {
        if( ev.keyName === "back" ) {
            var activePopup = document.querySelector( '.ui-popup-active' ),
                page = document.getElementsByClassName( 'ui-page-active' )[0],
                pageid = page ? page.id : "";

            if( pageid === "main" && !activePopup ) {
                try {
                    tizen.application.getCurrentApplication().exit();
                } catch (ignore) {
                }
            } else {
                window.history.back();
            }
        }
    } );

    

	// Pattern 2
function p21up() {
	return [70,1200,70,1100,70,900,70,600,70,300,70,300,70,300,70]
}

function p21down() {
	return [70,300,70,600,70,900,70,1200,70,1200,70,1200,70]
}

function p21thres() {
   return [70,600,70,600,70,600,70,600,70,600,70,600,70]
}

function p22up() {
	return [70,20,70,1200,70,20,70,1100,70,20,70,900,70,20,70,600,70,20,70,300,70,20,70,300,70,20,70]
}

function p22down() {
	return [70,20,70,300,70,20,70,600,70,20,70,900,70,20,70,1200,70,20,70,1200,70,20,70]
}

function p22thres() {
   return [70,20,70,600,70,20,70,600,70,20,70,600,70,20,70,600,70,20,70,600,70,20,70,600,70,20,70]
}

function p23up() {
	return [70,20,70,20,70,1200,70,20,70,20,70,1100,70,20,70,20,70,900,70,20,70,20,70,600,70,20,70,20,70,300,70,20,70,20,70,300,70,20,70,20,70]
}

function p23down() {
	return [70,20,70,20,70,300,70,20,70,20,70,600,70,20,70,20,70,900,70,20,70,20,70,1200,70,20,70,20,70,1200,70,20,70,20,70]
}

function p23thres() {
   return [70,20,70,20,70,600,70,20,70,20,70,600,70,20,70,20,70,600,70,20,70,20,70,600,70,20,70,20,70,600,70,20,70,20,70,600,70,20,70,20,70]
}

function p24up() {
	return [500,1200,500,1100,500,900,500,600,500,300,500,300,500]
}

function p24down() {
	return [500,300,500,600,500,900,500,1200,500,1200,500]
}

function p24thres() {
   return [500,600,500,600,500,600,500,600,500,600,500,600,500]
}

 function stopVibrationCB()
 	{
	 navigator.vibrate(0);
 	}
 
 function lowBuzz() {
    	return [800,50,300,500,];
    }

// "generated" patterns - Pattern 2
 function p21UPCB(){
	 navigator.vibrate(lowBuzz().concat(p21up()));
 }
 
 function p21DOWNCB(){
	 navigator.vibrate(lowBuzz().concat(p21down()));
 }
 
 function p21thresCB() {
	 navigator.vibrate(lowBuzz().concat(p21thres()));
 }
 
 function p22UPCB(){
	 navigator.vibrate(lowBuzz().concat(p22up()));
 }
 
 function p22DOWNCB(){
	 navigator.vibrate(lowBuzz().concat(p22down()));
 }
 
 function p22thresCB() {
	 navigator.vibrate(lowBuzz().concat(p22thres()));
 }
 
 function p23UPCB(){
	 navigator.vibrate(lowBuzz().concat(p23up()));
 }
 
 function p23DOWNCB(){
	 navigator.vibrate(lowBuzz().concat(p23down()));
 }
 
 function p23thresCB() {
	 navigator.vibrate(lowBuzz().concat(p23thres()));
 }
 
 function p24UPCB(){
	 navigator.vibrate(lowBuzz().concat(p24up()));
 }
 
 function p24DOWNCB(){
	 navigator.vibrate(lowBuzz().concat(p24down()));
 }
 
 function p24thresCB() {
	 navigator.vibrate(lowBuzz().concat(p24thres()));
 }
 
 function patternLOWBUZZCB()
 	{
	 navigator.vibrate(lowBuzz());
 	}
 
 function stopVibrationCB()
 	{
	 navigator.vibrate(0);
 	}
 	

	// Button Pattern 2

var pattern21UP = document.getElementById('pattern21UP');
pattern21UP.addEventListener('click',p21UPCB);

var pattern21DOWN = document.getElementById('pattern21DOWN');
pattern21DOWN.addEventListener('click',p21DOWNCB);

var pattern21THRES = document.getElementById('pattern21THRES');
pattern21THRES.addEventListener('click',p21thresCB);

var pattern22UP = document.getElementById('pattern22UP');
pattern22UP.addEventListener('click',p22UPCB);

var pattern22DOWN = document.getElementById('pattern22DOWN');
pattern22DOWN.addEventListener('click',p22DOWNCB);

var pattern22THRES = document.getElementById('pattern22THRES');
pattern22THRES.addEventListener('click',p22thresCB);

var pattern23UP = document.getElementById('pattern23UP');
pattern23UP.addEventListener('click',p23UPCB);

var pattern23DOWN = document.getElementById('pattern23DOWN');
pattern23DOWN.addEventListener('click',p23DOWNCB);

var pattern23THRES = document.getElementById('pattern23THRES');
pattern23THRES.addEventListener('click',p23thresCB);

var pattern24UP = document.getElementById('pattern24UP');
pattern24UP.addEventListener('click',p24UPCB);

var pattern24DOWN = document.getElementById('pattern24DOWN');
pattern24DOWN.addEventListener('click',p24DOWNCB);

var pattern24THRES = document.getElementById('pattern24THRES');
pattern24THRES.addEventListener('click',p24thresCB);

var patternLOWBUZZ = document.getElementById('patternLOWBUZZ');
patternLOWBUZZ.addEventListener('click', patternLOWBUZZCB);

var resetConnection = document.getElementById('resetConnection');
resetConnection.addEventListener('click', resetConnectionCB);

var stopVibration = document.getElementById('stopVibration');
stopVibration.addEventListener('click', stopVibrationCB);

// Wireless LAN adapter Local Area Connection* 2
	var webSocketUrl = 'ws://192.168.137.1:500/';
	
	function resetConnectionCB() {
		var webSocket = new WebSocket(webSocketUrl);

		function sendNote() {
			console.debug("woo hoo");
			console.log("send note?");
			console.log(webSocket.readyState);
			if(webSocket.readyState === 1) {
				pattern3THRESHCB();
				let message = {
					sender: "WATCH",
					msg: "You pressed a Button on a watch",
					warnings: false,
					warningList: [],
					graphData: []
				};
				webSocket.send(JSON.stringify(message));
			} else {
				//webSocket = new WebSocket(webSocketUrl); //attempting to reconnect
				console.log(webSocket.readyState);
				if (webSocket.readyState === 0) {
					pattern2THRESHCB();
				} else {
					pattern1THRESHCB();
				}
			}
			
		}
		
		var sendWebsocket = document.getElementById('sendWebsocket');
		sendWebsocket.addEventListener('click', sendNote);
		
		
	
		webSocket.onmessage = function(e) {
			console.log(e);
			var obj = JSON.parse(e.data).message;
			console.log(obj);
			if (obj.sender === "SERVER") {
				console.log('server message: ' + obj.msg);
				switch (obj.testing) {
				case "1up":
					tizen.power.turnScreenOn();
				      tizen.power.request('SCREEN', 'SCREEN_NORMAL');
				      tizen.power.request('CPU', 'CPU_AWAKE');
					pattern1UPCB();
					break;
				case "1down":
					tizen.power.turnScreenOn();
				      tizen.power.request('SCREEN', 'SCREEN_NORMAL');
				      tizen.power.request('CPU', 'CPU_AWAKE');
					pattern1DOWNCB();
					break;
				case "1":
					tizen.power.turnScreenOn();
				      tizen.power.request('SCREEN', 'SCREEN_NORMAL');
				      tizen.power.request('CPU', 'CPU_AWAKE');
					pattern1THRESHCB();
					break;
				case "2":
					tizen.power.turnScreenOn();
				      tizen.power.request('SCREEN', 'SCREEN_NORMAL');
				      tizen.power.request('CPU', 'CPU_AWAKE');
					pattern2THRESHCB();
					break;
				case "3up":
					tizen.power.turnScreenOn();
				      tizen.power.request('SCREEN', 'SCREEN_NORMAL');
				      tizen.power.request('CPU', 'CPU_AWAKE');
					pattern3UPCB();
					break;
				case "3down":
					tizen.power.turnScreenOn();
				      tizen.power.request('SCREEN', 'SCREEN_NORMAL');
				      tizen.power.request('CPU', 'CPU_AWAKE');
					pattern3DOWNCB();
					break;
				case "3":
					tizen.power.turnScreenOn();
				      tizen.power.request('SCREEN', 'SCREEN_NORMAL');
				      tizen.power.request('CPU', 'CPU_AWAKE');
					pattern3THRESHCB();
					break;
				case "4up":
					tizen.power.turnScreenOn();
				      tizen.power.request('SCREEN', 'SCREEN_NORMAL');
				      tizen.power.request('CPU', 'CPU_AWAKE');
					tizen.power.turnScreenOn();
				      tizen.power.request('SCREEN', 'SCREEN_NORMAL');
				      tizen.power.request('CPU', 'CPU_AWAKE');
					pattern4UPCB();
					break;
				case "4down":
					tizen.power.turnScreenOn();
				      tizen.power.request('SCREEN', 'SCREEN_NORMAL');
				      tizen.power.request('CPU', 'CPU_AWAKE');
					pattern4DOWNCB();
					break;
				case "4":
					tizen.power.turnScreenOn();
				      tizen.power.request('SCREEN', 'SCREEN_NORMAL');
				      tizen.power.request('CPU', 'CPU_AWAKE');
					pattern4THRESHCB();
					break;
				case "up":
					tizen.power.turnScreenOn();
				      tizen.power.request('SCREEN', 'SCREEN_NORMAL');
				      tizen.power.request('CPU', 'CPU_AWAKE');
					patternUPCB();
					break;
				case "down":
					tizen.power.turnScreenOn();
				      tizen.power.request('SCREEN', 'SCREEN_NORMAL');
				      tizen.power.request('CPU', 'CPU_AWAKE');
					patternDOWNCB();
					break;
				default:
					tizen.power.turnScreenOn();
			      tizen.power.request('SCREEN', 'SCREEN_NORMAL');
			      tizen.power.request('CPU', 'CPU_AWAKE');
					patternLOWBUZZCB();
					break;
				}
				console.log("did we get here?");
			}
			//if its not from the server ignore it
		};
		
		webSocket.onclose = function(e) {
			console.log("connection close, readyState: " + e.target.readyState);
		};
	}
	    
} () );