( function () {
    window.addEventListener( 'tizenhwkey', function( ev ) {
        if( ev.keyName === "back" ) {
            var activePopup = document.querySelector( '.ui-popup-active' ),
                page = document.getElementsByClassName( 'ui-page-active' )[0],
                pageid = page ? page.id : "";

            if( pageid === "testing" && !activePopup ) {
                try {
                    tizen.application.getCurrentApplication().exit();
                } catch (ignore) {
                }
            } else {
                window.history.back();
            }
        }
    } );
    function pat1() {
		 return [70,140,70,500];
	 }
	 
	 function pat2() {
		 return [1000,500];
	 }
	 
	 function pat3() {
		 return [300,400,300,400,300,500];
	 }
	 
	 function pat4() {
		 return [70,140,70,300,70,140,70,300,70,140,70,300,70,140,70,500];
	 }
	 
	 function patUp() {
		 return [70,140,70,140,370,500];
	 }
	 
	 function patDown() {
		 return [370,140,70,140,70,500];
	 }
	 
    
    function lowBuzz() {
    	return [20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,500];
    }
	 
    
    // "generated" patterns

    		
	 function pattern1UPCB()
	    {
		 navigator.vibrate(lowBuzz().concat(pat1().concat(lowBuzz().concat(patUp()))));
	    }
	 
	 function pattern1DOWNCB()
	    {
		 navigator.vibrate(lowBuzz().concat(pat1().concat(lowBuzz().concat(patDown()))));
	    }
	 
	 function pattern1THRESHCB()
	    {
		 navigator.vibrate(lowBuzz().concat(pat1()));
	    }

	 function pattern2THRESHCB()
	    {
		 navigator.vibrate(lowBuzz().concat(pat2()));
	    }
	 
	 function pattern3UPCB()
	    {
		 navigator.vibrate(lowBuzz().concat(pat3().concat(lowBuzz().concat(patUp()))));
	    }
	 
	 function pattern3DOWNCB()
	    {
		 navigator.vibrate(lowBuzz().concat(pat3().concat(lowBuzz().concat(patDown()))));
	    }
	 
	 function pattern3THRESHCB()
	    {
		 navigator.vibrate(lowBuzz().concat(pat3()));
	    }
	 
	 function pattern4UPCB()
	    {
		 navigator.vibrate(lowBuzz().concat(pat4().concat(lowBuzz().concat(patUp()))));
	    }
	 
	 function pattern4DOWNCB()
	    {
		 navigator.vibrate(lowBuzz().concat(pat4().concat(lowBuzz().concat(patDown()))));
	    }
	 
	 function pattern4THRESHCB()
	    {
		 navigator.vibrate(lowBuzz().concat(pat4()));
	    }
	 function patternUPCB()
	 	{
		 navigator.vibrate(lowBuzz().concat(patUp()));
	 	}
	 function patternDOWNCB()
	 	{
		 navigator.vibrate(lowBuzz().concat(patDown()));
	 	}
	 function patternLOWBUZZCB()
	 	{
		 navigator.vibrate(lowBuzz());
	 	}
	 
	 function stopVibrationCB()
	 	{
		 navigator.vibrate(0);
	 	}
	 
  

	var pattern1UP = document.getElementById('pattern1UP');
	pattern1UP.addEventListener('click', pattern1UPCB);
	
	var pattern1DOWN = document.getElementById('pattern1DOWN');
	pattern1DOWN.addEventListener('click', pattern1DOWNCB);
	
	var pattern1THRESH = document.getElementById('pattern1THRESH');
	pattern1THRESH.addEventListener('click', pattern1THRESHCB);
	
	var pattern2THRESH = document.getElementById('pattern2THRESH');
	pattern2THRESH.addEventListener('click', pattern2THRESHCB);
	
	var pattern3UP = document.getElementById('pattern3UP');
	pattern3UP.addEventListener('click', pattern3UPCB);
	
	var pattern3DOWN = document.getElementById('pattern3DOWN');
	pattern3DOWN.addEventListener('click', pattern3DOWNCB);
	
	var pattern3THRESH = document.getElementById('pattern3THRESH');
	pattern3THRESH.addEventListener('click', pattern3THRESHCB);
	
	var pattern4UP = document.getElementById('pattern4UP');
	pattern4UP.addEventListener('click', pattern4UPCB);
	
	var pattern4DOWN = document.getElementById('pattern4DOWN');
	pattern4DOWN.addEventListener('click', pattern4DOWNCB);
	
	var pattern4THRESH = document.getElementById('pattern4THRESH');
	pattern4THRESH.addEventListener('click', pattern4THRESHCB);
	
	var patternUP = document.getElementById('patternUP');
	patternUP.addEventListener('click', patternUPCB);
	
	var patternDOWN = document.getElementById('patternDOWN');
	patternDOWN.addEventListener('click', patternDOWNCB);
	
	var patternLOWBUZZ = document.getElementById('patternLOWBUZZ');
	patternLOWBUZZ.addEventListener('click', patternLOWBUZZCB);
	
	var resetConnection = document.getElementById('resetConnection');
	resetConnection.addEventListener('click', resetConnectionCB);
	
	var stopVibration = document.getElementById('stopVibration');
	stopVibration.addEventListener('click', stopVibrationCB);
    
	
		
		webSocket.onclose = function(e) {
			console.log("connection close, readyState: " + e.target.readyState);
		};
	
	
} () );
